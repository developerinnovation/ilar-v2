<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* modules/custom/ngt_general/templates/node-lesson/block--right-lesson.html.twig */
class __TwigTemplate_5d70cc2b66a5e823bf69b4cee9de56015f1f94c90c461ea290bc2bcb18e4f7bd extends \Twig\Template
{
    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = [
        ];
        $this->sandbox = $this->env->getExtension('\Twig\Extension\SandboxExtension');
        $tags = ["if" => 30, "for" => 33];
        $filters = ["escape" => 1, "image_style" => 11, "raw" => 27];
        $functions = ["drupal_block" => 62];

        try {
            $this->sandbox->checkSecurity(
                ['if', 'for'],
                ['escape', 'image_style', 'raw'],
                ['drupal_block']
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->getSourceContext());

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        // line 1
        echo "<div class=\"main-content\" id=\"lesson-";
        echo $this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed($this->getAttribute($this->getAttribute(($context["data"] ?? null), 0, [], "array"), "nid", [])), "html", null, true);
        echo "\">
    <div class=\"course-action\">
        <select name=\"\" id=\"\">
            <option value=\"\" selected>Presentación</option>
            <option value=\"\">Contenidos</option>
            <option value=\"\">Comunidad</option>
        </select>
    </div>
    <figure class=\"content-video\">
        <picture class=\"cover-video active\">
            <source srcset=\"";
        // line 11
        echo $this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->env->getExtension('Drupal\twig_tweak\TwigExtension')->imageStyle($this->sandbox->ensureToStringAllowed($this->getAttribute($this->getAttribute($this->getAttribute(($context["data"] ?? null), 0, [], "array"), "foto_portada", []), "uri", [])), "360x196"), "html", null, true);
        echo "\" 
                media=\"(max-width: 767px)\" 
                alt=\"";
        // line 13
        echo $this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed($this->getAttribute($this->getAttribute($this->getAttribute(($context["data"] ?? null), 0, [], "array"), "foto_portada", []), "alt", [])), "html", null, true);
        echo "\" 
                title=\"";
        // line 14
        echo $this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed($this->getAttribute($this->getAttribute($this->getAttribute(($context["data"] ?? null), 0, [], "array"), "foto_portada", []), "title", [])), "html", null, true);
        echo "\">
            <img srcset=\"";
        // line 15
        echo $this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->env->getExtension('Drupal\twig_tweak\TwigExtension')->imageStyle($this->sandbox->ensureToStringAllowed($this->getAttribute($this->getAttribute($this->getAttribute(($context["data"] ?? null), 0, [], "array"), "foto_portada", []), "uri", [])), "604x476"), "html", null, true);
        echo "\" 
                alt=\"";
        // line 16
        echo $this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed($this->getAttribute($this->getAttribute($this->getAttribute(($context["data"] ?? null), 0, [], "array"), "foto_portada", []), "alt", [])), "html", null, true);
        echo "\" 
                title=\"";
        // line 17
        echo $this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed($this->getAttribute($this->getAttribute($this->getAttribute(($context["data"] ?? null), 0, [], "array"), "foto_portada", []), "title", [])), "html", null, true);
        echo "\">
        </picture>
        <video id=\"presentation\" preload=\"auto\" src=\"";
        // line 19
        echo $this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed($this->getAttribute($this->getAttribute(($context["data"] ?? null), 0, [], "array"), "video", [])), "html", null, true);
        echo "\" controls>
            Tu navegador no implementa el elemento <code>video</code>.
        </video>
    </figure>

    <div class=\"content-tab presentation\">
        <h2>Resumen</h2>
        <div class=\"description\">
            ";
        // line 27
        echo $this->env->getExtension('Drupal\Core\Template\TwigExtension')->renderVar($this->sandbox->ensureToStringAllowed($this->getAttribute($this->getAttribute(($context["data"] ?? null), 0, [], "array"), "body", [])));
        echo "
        </div>
        <h3>Recursos</h3>
        ";
        // line 30
        if ( !(null === $this->getAttribute($this->getAttribute(($context["data"] ?? null), 0, [], "array"), "recursos", []))) {
            // line 31
            echo "            <div class=\"list recurses\">
                <ul>
                    ";
            // line 33
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable($this->getAttribute($this->getAttribute(($context["data"] ?? null), 0, [], "array"), "recursos", []));
            foreach ($context['_seq'] as $context["key"] => $context["recurso"]) {
                // line 34
                echo "                        <li>
                            <div class=\"left\">
                                <i class=\"icon download\"></i>
                            </div>
                            <div class=\"right\">
                                <h4>";
                // line 39
                echo $this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed($this->getAttribute($context["recurso"], "title", [])), "html", null, true);
                echo "</h4>
                                <span class=\"format\">";
                // line 40
                echo $this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed($this->getAttribute($context["recurso"], "extension", [])), "html", null, true);
                echo "</span>
                                <p>";
                // line 41
                echo $this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed($this->getAttribute($context["recurso"], "description", [])), "html", null, true);
                echo "</p>
                            </div>
                            <div class=\"download\">
                                <a download href=\"";
                // line 44
                echo $this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed($this->getAttribute($context["recurso"], "url", [])), "html", null, true);
                echo "\">Descargar</a>
                            </div>
                        </li>
                    ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['key'], $context['recurso'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 48
            echo "                </ul>
            </div>
        ";
        }
        // line 51
        echo "    </div>
</div>
<div class=\"nav-leccion desktop\">
    <div class=\"preview\">
        <a href=\"";
        // line 55
        echo $this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed($this->getAttribute($this->getAttribute(($context["data"] ?? null), 0, [], "array"), "nextLesson", [])), "html", null, true);
        echo "\"><i class=\"icon row\"></i>Volver</a>
    </div>
    <div class=\"next\">
        <a href=\"";
        // line 58
        echo $this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed($this->getAttribute($this->getAttribute(($context["data"] ?? null), 0, [], "array"), "prevLesson", [])), "html", null, true);
        echo "\"><i class=\"icon row\"></i>Siguiente lección</a>
    </div>
</div>
<div class=\"mobile\">
    ";
        // line 62
        echo $this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->env->getExtension('Drupal\twig_tweak\TwigExtension')->drupalBlock("ngt_general_node_lesson_modules", ["node" => $this->getAttribute($this->getAttribute(($context["data"] ?? null), 0, [], "array"), "nid", [])]), "html", null, true);
        echo "
</div>
";
    }

    public function getTemplateName()
    {
        return "modules/custom/ngt_general/templates/node-lesson/block--right-lesson.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  177 => 62,  170 => 58,  164 => 55,  158 => 51,  153 => 48,  143 => 44,  137 => 41,  133 => 40,  129 => 39,  122 => 34,  118 => 33,  114 => 31,  112 => 30,  106 => 27,  95 => 19,  90 => 17,  86 => 16,  82 => 15,  78 => 14,  74 => 13,  69 => 11,  55 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Source("<div class=\"main-content\" id=\"lesson-{{ data[0].nid }}\">
    <div class=\"course-action\">
        <select name=\"\" id=\"\">
            <option value=\"\" selected>Presentación</option>
            <option value=\"\">Contenidos</option>
            <option value=\"\">Comunidad</option>
        </select>
    </div>
    <figure class=\"content-video\">
        <picture class=\"cover-video active\">
            <source srcset=\"{{ data[0].foto_portada.uri | image_style('360x196') }}\" 
                media=\"(max-width: 767px)\" 
                alt=\"{{ data[0].foto_portada.alt }}\" 
                title=\"{{ data[0].foto_portada.title }}\">
            <img srcset=\"{{ data[0].foto_portada.uri | image_style('604x476') }}\" 
                alt=\"{{ data[0].foto_portada.alt }}\" 
                title=\"{{ data[0].foto_portada.title }}\">
        </picture>
        <video id=\"presentation\" preload=\"auto\" src=\"{{ data[0].video }}\" controls>
            Tu navegador no implementa el elemento <code>video</code>.
        </video>
    </figure>

    <div class=\"content-tab presentation\">
        <h2>Resumen</h2>
        <div class=\"description\">
            {{ data[0].body|raw }}
        </div>
        <h3>Recursos</h3>
        {% if data[0].recursos is not null %}
            <div class=\"list recurses\">
                <ul>
                    {% for key, recurso in data[0].recursos %}
                        <li>
                            <div class=\"left\">
                                <i class=\"icon download\"></i>
                            </div>
                            <div class=\"right\">
                                <h4>{{ recurso.title }}</h4>
                                <span class=\"format\">{{ recurso.extension }}</span>
                                <p>{{ recurso.description }}</p>
                            </div>
                            <div class=\"download\">
                                <a download href=\"{{ recurso.url }}\">Descargar</a>
                            </div>
                        </li>
                    {% endfor %}
                </ul>
            </div>
        {% endif %}
    </div>
</div>
<div class=\"nav-leccion desktop\">
    <div class=\"preview\">
        <a href=\"{{ data[0].nextLesson }}\"><i class=\"icon row\"></i>Volver</a>
    </div>
    <div class=\"next\">
        <a href=\"{{ data[0].prevLesson }}\"><i class=\"icon row\"></i>Siguiente lección</a>
    </div>
</div>
<div class=\"mobile\">
    {{ drupal_block('ngt_general_node_lesson_modules', { 'node' : data[0].nid }) }}
</div>
", "modules/custom/ngt_general/templates/node-lesson/block--right-lesson.html.twig", "/Applications/MAMP/htdocs/ILAR/web/modules/custom/ngt_general/templates/node-lesson/block--right-lesson.html.twig");
    }
}
